export const clientId = '1051426514050-dv0o9fu9umand32ov9iqcamvuf9gttta.apps.googleusercontent.com'

export const iconPDF = 'https://cdn4.iconfinder.com/data/icons/logos-and-brands/512/27_Pdf_File_Type_Adobe_logo_logos-512.png';
export const defaultProfilePicture = 'https://static.straitstimes.com.sg/s3fs-public/articles/2020/12/01/af_moneyheist_011220.jpg';
export const emptyChatImage = 'https://i.gadgets360cdn.com/large/whatsapp_multi_device_support_update_image_1636207150180.jpg';
export const qrCodeImage = 'https://www.ginifab.com/feeds/qr_code/img/qrcode.jpg';
export const emptyProfilePicture = 'https://www.kindpng.com/picc/m/78-785827_user-profile-avatar-login-account-male-user-icon.png';